from django.urls import path
from . import views
from django.conf.urls import url

from django.urls import path
from . import views
from django.conf.urls import url

urlpatterns = [
    url(r'^data/$', views.get_data, name='get_data'),
    url(r'^return_data/$', views.return_data, name='return_data')
]


