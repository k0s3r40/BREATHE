from django.contrib import admin
from manager.models import *
admin.register(data)
admin.register(data_new)
# Register your models here.
