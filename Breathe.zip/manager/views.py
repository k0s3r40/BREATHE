from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from manager.models import data, data_new

def home(request):
    return render(request, '../templates/home.html')


def get_data(request):
    if request.method == "GET":
        m = request.GET['message'].split("_")
        for i in range(0,len(m)):
            if float(m[i]) < 0:
                m[i] = 0
            if float(m[i]) > 5:
                m[i] = 5






        save = data_new.objects.create(
        dust=m[0],
        smoke = m[1],
        co = m[2],
        lpg = m[3],

        )
        save.save()



        return HttpResponse("GET")
    return HttpResponse('OK')

from django.core.serializers import serialize

from django.core.serializers.json import DjangoJSONEncoder
from django.core import serializers
# serialize queryset


def return_data(request):
    serialized_queryset = serializers.serialize('json', data_new.objects.all())
    return HttpResponse(serialized_queryset)

