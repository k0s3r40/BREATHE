from django.db import models
from django.utils import timezone
# Create your models here.

class data(models.Model):
    class Meta:
        verbose_name = "Data"
    type = models.CharField(null=True, blank=True, max_length=255)
    value = models.CharField(null=True, blank=True, max_length=255)
    time = models.DateTimeField(default=timezone.now, blank=True, )
    def __str__(self):
        return '{}'.format(self.id)



class data_new(models.Model):
    dust = models.CharField(null=True, blank=True, max_length=255)
    co = models.CharField(null=True, blank=True, max_length=255)
    smoke = models.CharField(null=True, blank=True, max_length=255)
    lpg = models.CharField(null=True, blank=True, max_length=255)
    time = models.DateTimeField(default=timezone.now, blank=True, )

    def __str__(self):
        return '{}'.format(self.name)